/*global define*/
define([
    'app/collections/ProxyBase.Collection',
    'app/models/Nessus',
    'app/config/ContextMap'
], function (
    BaseCollection,
    Nessus,
    ContextMap
) {
    return BaseCollection.extend({
        url: [
            ContextMap.restRoot,
            ContextMap.nessus
        ].join('/'),
        model: Nessus,
        initialize: function (attributes, options) {
            BaseCollection.prototype.initialize.call(this, attributes, options);
        }
    });
});
