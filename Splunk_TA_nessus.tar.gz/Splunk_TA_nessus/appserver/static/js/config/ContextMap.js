/*global define*/
define(function () {
    return {
        "appName": "Splunk_TA_nessus",
        "restRoot": "ta_tenable",
        "input": "ta_tenable_sc_inputs",
        "nessus": "ta_tenable_nessus_inputs",
        "server": "ta_tenable_sc_servers",
        "index": "ta_tenable_indexes",
        "setting": "ta_tenable_settings"
    };
});
